package com.applecare.apple_repair_service.service;

import com.applecare.apple_repair_service.dto.request.CreateServiceIssueRequest;
import com.applecare.apple_repair_service.dto.request.UpdateServiceIssueRequest;
import com.applecare.apple_repair_service.dto.response.ServiceIssueResponse;
import com.applecare.apple_repair_service.entity.ServiceIssue;
import com.applecare.apple_repair_service.entity.DeviceType;
import com.applecare.apple_repair_service.enums.ActiveStatus;
import com.applecare.apple_repair_service.exception.DuplicateResourceException;
import com.applecare.apple_repair_service.exception.ConflictException;
import com.applecare.apple_repair_service.mapper.EntityResponses;
import com.applecare.apple_repair_service.repository.ServiceIssueRepository;
import com.applecare.apple_repair_service.repository.AdminReferenceRepository;
import com.applecare.apple_repair_service.repository.ServiceCatalogItemRepository;

import java.util.List;
import java.util.Objects;
import java.util.HashSet;

import lombok.RequiredArgsConstructor;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ServiceIssueService {
    private final ServiceIssueRepository repository;
    private final DomainAccess access;
    private final BusinessRules rules;
    private final EntityResponses mapper;
    private final AdminReferenceRepository references;
    private final ServiceCatalogItemRepository catalog;

    public ServiceIssueResponse getById(Long id) {
        return mapper.map(access.get(ServiceIssue.class, id));
    }

    public List<ServiceIssueResponse> list() {
        return repository.findAll().stream().map(mapper::map).toList();
    }

    @Transactional(isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public ServiceIssueResponse create(CreateServiceIssueRequest r) {
        rules.validate(r);
        var e = new ServiceIssue();
        apply(e, new UpdateServiceIssueRequest(r.name(), r.deviceTypeIds()));
        return save(e);
    }

    @Transactional(isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public ServiceIssueResponse update(Long id, UpdateServiceIssueRequest r) {
        rules.validate(r);
        var e = access.lock(ServiceIssue.class, id);
        apply(e, r);
        return save(e);
    }

    @Transactional(isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public ServiceIssueResponse activate(Long id) {
        var e = access.lock(ServiceIssue.class, id);
        e.setStatus(ActiveStatus.ACTIVE);
        return save(e);
    }

    @Transactional(isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public ServiceIssueResponse deactivate(Long id) {
        var e = access.lock(ServiceIssue.class, id);
        e.setStatus(ActiveStatus.INACTIVE);
        return save(e);
    }

    @Transactional(isolation = org.springframework.transaction.annotation.Isolation.READ_COMMITTED)
    public void delete(Long id) {
        var entity = access.lock(ServiceIssue.class, id);
        String message = "Không thể xóa nhóm vấn đề vì dữ liệu này đang được sử dụng.";
        if (references.serviceIssueIsReferenced(id)) throw new ConflictException(message);
        try {
            repository.delete(entity);
            repository.flush();
        } catch (DataIntegrityViolationException ex) {
            throw new ConflictException(message, ex);
        }
    }

    private void apply(ServiceIssue e, UpdateServiceIssueRequest r) {
        repository.findByNameIgnoreCase(r.name().trim()).filter(x -> !Objects.equals(x.getId(), e.getId())).ifPresent(x -> {
            throw new DuplicateResourceException("Name already exists");
        });
        e.setName(BusinessRules.text(r.name()));
        var types = new HashSet<DeviceType>();
        for (Long typeId : r.deviceTypeIds()) {
            var type = access.get(DeviceType.class, typeId);
            BusinessRules.require(type.getStatus() == ActiveStatus.ACTIVE, "Loại thiết bị đã ngừng sử dụng.");
            types.add(type);
        }
        if (e.getId() != null) {
            for (var existing : e.getDeviceTypes()) {
                BusinessRules.require(types.stream().anyMatch(type -> type.getId().equals(existing.getId()))
                                || !catalog.existsByServiceIssue_IdAndDeviceModel_DeviceType_Id(e.getId(), existing.getId()),
                        "Không thể bỏ loại thiết bị đang được danh mục dịch vụ sử dụng.");
            }
        }
        e.getDeviceTypes().clear();
        e.getDeviceTypes().addAll(types);
        e.setMappingInitialized(true);
    }

    private ServiceIssueResponse save(ServiceIssue e) {
        try {
            return mapper.map(repository.saveAndFlush(e));
        } catch (DataIntegrityViolationException ex) {
            throw new DuplicateResourceException("ServiceIssue conflicts with an existing unique key");
        }
    }
}
