package com.applecare.apple_repair_service.dto.request;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record ReversePartUsageRequest(
        @NotNull @Positive Long partUsageId, @NotNull @Positive Long reversedByUserId, String reversalNote
) {
}
