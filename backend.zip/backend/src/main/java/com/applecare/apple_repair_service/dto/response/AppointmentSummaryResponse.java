package com.applecare.apple_repair_service.dto.response;

import com.applecare.apple_repair_service.enums.AppointmentStatus;

import java.time.LocalDateTime;

public record AppointmentSummaryResponse(Long id, Long customerId, Long appointmentSlotId, AppointmentStatus status,
                                         LocalDateTime bookedAt) {
}
