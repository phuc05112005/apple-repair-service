package com.applecare.apple_repair_service.service;

import com.applecare.apple_repair_service.dto.auth.LoginRequest;
import com.applecare.apple_repair_service.dto.command.StockAdjustmentCommand;
import com.applecare.apple_repair_service.dto.command.StockInCommand;
import com.applecare.apple_repair_service.dto.request.*;
import com.applecare.apple_repair_service.entity.*;
import com.applecare.apple_repair_service.enums.*;
import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.webmvc.test.autoconfigure.*;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.databind.ObjectMapper;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.math.BigDecimal;
import java.time.LocalTime;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.hamcrest.Matchers.containsString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc(print=MockMvcPrint.NONE)
@Transactional
class AdminApiIntegrationTest {
    @Autowired MockMvc mvc;
    @Autowired EntityManager em;
    @Autowired ObjectMapper json;
    @Autowired Clock clock;
    @Autowired PasswordEncoder encoder;
    ApiFixture f;
    String token;
    @BeforeEach void fixture() throws Exception {
        f=new ApiFixture(em,clock); f.create();
        var response=mvc.perform(post("/api/v1/auth/login").contentType("application/json")
                .content(json.writeValueAsString(new LoginRequest(f.admin.getUsername(),ApiFixture.PASSWORD))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        token=json.readTree(response).get("accessToken").asString();
    }
    @Test void adminCreatesHashedUsersAndDuplicateUsernameIs409() throws Exception {
        var request=new CreateUserRequest(f.prefix+"new",ApiFixture.PASSWORD,"New technician",null,UserRole.TECHNICIAN);
        String body=json.writeValueAsString(request);
        String response=mvc.perform(post("/api/v1/admin/users").header("Authorization","Bearer "+token)
                .contentType("application/json").content(body)).andExpect(status().isCreated())
                .andExpect(jsonPath("$.passwordHash").doesNotExist()).andExpect(jsonPath("$.password").doesNotExist())
                .andReturn().getResponse().getContentAsString();
        long id=json.readTree(response).get("id").asLong();
        assertTrue(encoder.matches(ApiFixture.PASSWORD,em.find(User.class,id).getPasswordHash()));
        mvc.perform(get("/api/v1/admin/users/"+id).header("Authorization","Bearer "+token))
                .andExpect(status().isOk()).andExpect(jsonPath("$.role").value("TECHNICIAN"));
        mvc.perform(post("/api/v1/admin/users").header("Authorization","Bearer "+token).contentType("application/json").content(body))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("DUPLICATE_RESOURCE"));
    }
    @Test void adminResetsEmployeePasswordAndRevokesOldSession() throws Exception {
        String originalHash = f.receptionist.getPasswordHash();
        String employeeToken = json.readTree(mvc.perform(post("/api/v1/auth/login").contentType("application/json")
                .content(json.writeValueAsString(new LoginRequest(f.receptionist.getUsername(), ApiFixture.PASSWORD))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString()).get("accessToken").asString();
        String path = "/api/v1/admin/users/" + f.receptionist.getId() + "/password";
        String body = json.writeValueAsString(new ResetUserPasswordRequest("Fresh-password-2026!"));
        mvc.perform(put(path).header("Authorization", "Bearer " + employeeToken)
                .contentType("application/json").content(body)).andExpect(status().isForbidden());
        mvc.perform(put(path).header("Authorization", "Bearer " + token)
                .contentType("application/json").content(body)).andExpect(status().isNoContent());
        em.flush(); em.clear();
        assertTrue(encoder.matches("Fresh-password-2026!", em.find(User.class, f.receptionist.getId()).getPasswordHash()));
        assertNotEquals(originalHash, em.find(User.class, f.receptionist.getId()).getPasswordHash());
        mvc.perform(post("/api/v1/auth/login").contentType("application/json")
                .content(json.writeValueAsString(new LoginRequest(f.receptionist.getUsername(), ApiFixture.PASSWORD))))
                .andExpect(status().isUnauthorized());
        mvc.perform(get("/api/v1/auth/me").header("Authorization", "Bearer " + employeeToken))
                .andExpect(status().isUnauthorized());
        mvc.perform(post("/api/v1/auth/login").contentType("application/json")
                .content(json.writeValueAsString(new LoginRequest(f.receptionist.getUsername(), "Fresh-password-2026!"))))
                .andExpect(status().isOk());
        mvc.perform(put("/api/v1/admin/users/999999999/password").header("Authorization", "Bearer " + token)
                .contentType("application/json").content(body)).andExpect(status().isNotFound());
        mvc.perform(put(path).header("Authorization", "Bearer " + token).contentType("application/json")
                .content(json.writeValueAsString(new ResetUserPasswordRequest("short"))))
                .andExpect(status().isBadRequest());
    }
    @Test void receptionistCannotChangeWeeklyAppointmentConfiguration() throws Exception {
        var response = mvc.perform(post("/api/v1/auth/login").contentType("application/json")
                .content(json.writeValueAsString(new LoginRequest(f.receptionist.getUsername(), ApiFixture.PASSWORD))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        String receptionistToken = json.readTree(response).get("accessToken").asString();
        mvc.perform(get("/api/v1/admin/appointment-weekly-schedules").param("branchId", f.branch.getId().toString())
                .header("Authorization", "Bearer " + receptionistToken)).andExpect(status().isForbidden());
        mvc.perform(put("/api/v1/admin/appointment-weekly-schedules").header("Authorization", "Bearer " + receptionistToken)
                .contentType("application/json").content(json.writeValueAsString(new SaveWeeklyScheduleRequest(
                        f.branch.getId(), 1, true, List.of(new SlotRule(LocalTime.of(9, 0), LocalTime.of(10, 0), true))))))
                .andExpect(status().isForbidden());
    }
    @Test void onlyAdminCanConfigureValidatedOnlineBookingDiscount() throws Exception {
        String receptionistToken = login(f.receptionist);
        String url = "/api/v1/admin/system-settings/" + PricePolicy.ONLINE_BOOKING_DISCOUNT_PERCENT;
        mvc.perform(put(url).header("Authorization", "Bearer " + receptionistToken)
                .contentType("application/json").content("{\"settingValue\":\"5\"}"))
                .andExpect(status().isForbidden());
        mvc.perform(put(url).header("Authorization", "Bearer " + token)
                .contentType("application/json").content("{\"settingValue\":\"5\"}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.settingValue").value("5"));
        mvc.perform(put(url).header("Authorization", "Bearer " + token)
                .contentType("application/json").content("{\"settingValue\":\"101\"}"))
                .andExpect(status().isBadRequest());
        mvc.perform(put(url).header("Authorization", "Bearer " + token)
                .contentType("application/json").content("{\"settingValue\":\"0\"}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.settingValue").value("0"));
    }
    @Test void adminUpdatesDisablesReactivatesUsersButCannotDisableSelf() throws Exception {
        var request=new CreateUserRequest(f.prefix+"reception-new",ApiFixture.PASSWORD,"New receptionist",null,UserRole.RECEPTIONIST);
        var created=mvc.perform(post("/api/v1/admin/users").header("Authorization","Bearer "+token)
                .contentType("application/json").content(json.writeValueAsString(request))).andExpect(status().isCreated())
                .andReturn().getResponse().getContentAsString();
        long id=json.readTree(created).get("id").asLong();
        mvc.perform(put("/api/v1/admin/users/"+id+"/profile").header("Authorization","Bearer "+token)
                .contentType("application/json").content(json.writeValueAsString(new UpdateUserProfileRequest("Updated receptionist","0900000000"))))
                .andExpect(status().isOk()).andExpect(jsonPath("$.fullName").value("Updated receptionist"));
        mvc.perform(put("/api/v1/admin/users/"+id+"/status").header("Authorization","Bearer "+token)
                .contentType("application/json").content(json.writeValueAsString(new UpdateUserStatusRequest(UserStatus.INACTIVE))))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("INACTIVE"));
        mvc.perform(post("/api/v1/auth/login").contentType("application/json")
                .content(json.writeValueAsString(new LoginRequest(request.username(),request.password())))).andExpect(status().isUnauthorized());
        mvc.perform(put("/api/v1/admin/users/"+id+"/status").header("Authorization","Bearer "+token)
                .contentType("application/json").content(json.writeValueAsString(new UpdateUserStatusRequest(UserStatus.ACTIVE))))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("ACTIVE"));
        mvc.perform(post("/api/v1/auth/login").contentType("application/json")
                .content(json.writeValueAsString(new LoginRequest(request.username(),request.password())))).andExpect(status().isOk())
                .andExpect(jsonPath("$.user.role").value("RECEPTIONIST"));
        mvc.perform(put("/api/v1/admin/users/"+f.admin.getId()+"/status").header("Authorization","Bearer "+token)
                .contentType("application/json").content(json.writeValueAsString(new UpdateUserStatusRequest(UserStatus.INACTIVE))))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.code").value("BUSINESS_RULE_VIOLATION"));
    }
    @Test void masterCommandsAndStatisticsRequireAdminAndReturnTypedData() throws Exception {
        mvc.perform(post("/api/v1/admin/device-types").header("Authorization","Bearer "+token)
                .contentType("application/json").content(json.writeValueAsString(new CreateDeviceTypeRequest(f.deviceType.getName()))))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("DUPLICATE_RESOURCE"));
        mvc.perform(post("/api/v1/admin/device-types/"+f.deviceType.getId()+"/deactivate").header("Authorization","Bearer "+token))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("INACTIVE"));
        mvc.perform(post("/api/v1/admin/device-types/"+f.deviceType.getId()+"/activate").header("Authorization","Bearer "+token))
                .andExpect(status().isOk()).andExpect(jsonPath("$.status").value("ACTIVE"));
        mvc.perform(get("/api/v1/admin/statistics/overview").header("Authorization","Bearer "+token)
                .param("from",LocalDate.now(clock).toString()).param("to",LocalDate.now(clock).toString()).param("branchId",f.branch.getId().toString()))
                .andExpect(status().isOk()).andExpect(jsonPath("$.totalTickets").value(0)).andExpect(jsonPath("$.currentStatusCounts").isArray());
        mvc.perform(get("/api/v1/admin/branches/"+Long.MAX_VALUE).header("Authorization","Bearer "+token))
                .andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("RESOURCE_NOT_FOUND"));
    }
    @Test void stockCommandsUseAuthenticatedActorRejectSpoofingAndReportInsufficientStock() throws Exception {
        var part=new Part();part.setPartCode(f.prefix);part.setName(f.prefix);part.setSalePrice(BigDecimal.TEN);em.persist(part);em.flush();
        var command=new StockInCommand(f.prefix+"-LOT-01",f.branch.getId(),part.getId(),2,
                LocalDateTime.now(clock).minusMinutes(1),"fixture");
        String body=json.writeValueAsString(command);
        String spoof=body.substring(0,body.length()-1)+",\"recordedByUserId\":"+f.technician.getId()+"}";
        mvc.perform(post("/api/v1/admin/inventory/stock-in").header("Authorization","Bearer "+token)
                .contentType("application/json").content(spoof)).andExpect(status().isBadRequest());
        mvc.perform(post("/api/v1/admin/inventory/stock-in").header("Authorization","Bearer "+token)
                .contentType("application/json").content(body)).andExpect(status().isOk())
                .andExpect(jsonPath("$.lot.lotCode").value(command.lotCode()))
                .andExpect(jsonPath("$.transaction.transactionCode", containsString("NHAP_")))
                .andExpect(jsonPath("$.inventory.quantity").value(2));
        mvc.perform(get("/api/v1/admin/inventory").header("Authorization","Bearer "+token)
                .param("branchId",f.branch.getId().toString()).param("partId",part.getId().toString()))
                .andExpect(status().isOk()).andExpect(jsonPath("$", org.hamcrest.Matchers.hasSize(1)))
                .andExpect(jsonPath("$[0].quantity").value(2));
        mvc.perform(get("/api/v1/admin/parts/"+part.getId()+"/inventory-transactions")
                .header("Authorization","Bearer "+token))
                .andExpect(status().isOk()).andExpect(jsonPath("$", org.hamcrest.Matchers.hasSize(1)))
                .andExpect(jsonPath("$[0].transactionType").value("STOCK_IN"))
                .andExpect(jsonPath("$[0].transactionCode", containsString("NHAP_")));
        mvc.perform(get("/api/v1/admin/inventory/transactions").header("Authorization","Bearer "+token)
                .param("branchId", f.branch.getId().toString()).param("partId", part.getId().toString())
                .param("transactionType", "STOCK_IN").param("code", command.lotCode())
                .param("from", LocalDate.now(clock).minusDays(1).toString()).param("to", LocalDate.now(clock).toString()))
                .andExpect(status().isOk()).andExpect(jsonPath("$", org.hamcrest.Matchers.hasSize(1)))
                .andExpect(jsonPath("$[0].lotCode").value(command.lotCode()));
        mvc.perform(get("/api/v1/admin/inventory/transactions").header("Authorization","Bearer "+token)
                .param("partId", part.getId().toString()).param("code", "NHAP_"))
                .andExpect(status().isOk()).andExpect(jsonPath("$", org.hamcrest.Matchers.hasSize(1)));
        mvc.perform(get("/api/v1/admin/inventory/transactions").header("Authorization","Bearer "+token)
                .param("branchId", f.branch.getId().toString()).param("partId", part.getId().toString()))
                .andExpect(status().isOk()).andExpect(jsonPath("$", org.hamcrest.Matchers.hasSize(1)));
        mvc.perform(get("/api/v1/admin/inventory/import-template").header("Authorization","Bearer "+token))
                .andExpect(status().isOk())
                .andExpect(header().string("Content-Type", containsString("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")));
        mvc.perform(get("/api/v1/admin/inventory").header("Authorization","Bearer "+login(f.receptionist)))
                .andExpect(status().isForbidden());
        mvc.perform(get("/api/v1/admin/inventory/transactions").header("Authorization","Bearer "+login(f.receptionist)))
                .andExpect(status().isForbidden());
        mvc.perform(get("/api/v1/admin/inventory/import-template").header("Authorization","Bearer "+login(f.receptionist)))
                .andExpect(status().isForbidden());
        em.flush();
        var movement=em.createQuery("select t from InventoryTransaction t where t.part.id=:id",InventoryTransaction.class)
                .setParameter("id",part.getId()).getSingleResult();
        assertEquals(f.admin.getId(),movement.getRecordedBy().getId());
        mvc.perform(post("/api/v1/admin/inventory/stock-out").header("Authorization","Bearer "+token)
                .contentType("application/json").content(json.writeValueAsString(new StockAdjustmentCommand(f.branch.getId(),part.getId(),3,null))))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("INSUFFICIENT_STOCK"));
    }

    @Test void adminStoresWarrantyCharacteristicWithoutBindingAService() throws Exception {
        var replacementType = new ServiceType();
        replacementType.setCode(ServiceTypeCode.REPLACEMENT);
        replacementType.setName(f.prefix + " replacement");
        em.persist(replacementType);
        var standardPart = new Part(); standardPart.setPartCode(f.prefix + "-STD"); standardPart.setName("Pin tiêu chuẩn");
        standardPart.setBrand("Pisen"); standardPart.setVariant("Tiêu chuẩn"); standardPart.setSalePrice(BigDecimal.TEN); em.persist(standardPart);
        var highPart = new Part(); highPart.setPartCode(f.prefix + "-HIGH"); highPart.setName("Pin dung lượng cao");
        highPart.setBrand("Pisen"); highPart.setVariant("Dung lượng cao"); highPart.setSalePrice(BigDecimal.TEN); em.persist(highPart);
        var standard = new ServiceCatalogItem(); standard.setDeviceModel(f.model); standard.setServiceIssue(f.issue);
        standard.setServiceType(replacementType); standard.setPart(standardPart); standard.setName(f.prefix + " standard");
        standard.setStandardDurationMinutes(45); standard.setWarrantyDays(0); em.persist(standard);
        var high = new ServiceCatalogItem(); high.setDeviceModel(f.model); high.setServiceIssue(f.issue);
        high.setServiceType(replacementType); high.setPart(highPart); high.setName(f.prefix + " high");
        high.setStandardDurationMinutes(60); high.setWarrantyDays(180); high.setWarrantyRemedy(WarrantyRemedy.REPAIR); em.persist(high);
        em.flush();
        String url = "/api/v1/admin/service-catalog-items/" + high.getId();

        var same = new UpdateServiceCatalogItemRequest(f.model.getId(), replacementType.getId(), f.issue.getId(),
                highPart.getId(), null, null, 60, 180, WarrantyRemedy.REPLACEMENT, high.getId());
        mvc.perform(put(url).header("Authorization", "Bearer " + token).contentType("application/json")
                .content(json.writeValueAsString(same))).andExpect(status().isOk())
                .andExpect(jsonPath("$.warrantyRemedy").value("REPLACEMENT"))
                .andExpect(jsonPath("$.warrantyReplacementCatalogId").doesNotExist());

        var different = new UpdateServiceCatalogItemRequest(f.model.getId(), replacementType.getId(), f.issue.getId(),
                highPart.getId(), null, null, 60, 180, WarrantyRemedy.REPLACEMENT, standard.getId());
        mvc.perform(put(url).header("Authorization", "Bearer " + token).contentType("application/json")
                .content(json.writeValueAsString(different))).andExpect(status().isOk())
                .andExpect(jsonPath("$.warrantyRemedy").value("REPLACEMENT"))
                .andExpect(jsonPath("$.warrantyReplacementCatalogId").doesNotExist());

        var repair = new UpdateServiceCatalogItemRequest(f.model.getId(), replacementType.getId(), f.issue.getId(),
                highPart.getId(), null, null, 60, 180, WarrantyRemedy.REPAIR, null);
        mvc.perform(put(url).header("Authorization", "Bearer " + token).contentType("application/json")
                .content(json.writeValueAsString(repair))).andExpect(status().isOk())
                .andExpect(jsonPath("$.warrantyRemedy").value("REPAIR"))
                .andExpect(jsonPath("$.warrantyReplacementCatalogId").doesNotExist());
    }

    @Test void adminPhysicallyDeletesEverySupportedUnreferencedRecord() throws Exception {
        var branch = new Branch(); branch.setName(f.prefix+"-delete-branch"); branch.setAddress("Delete test"); em.persist(branch);
        var deviceType = new DeviceType(); deviceType.setName(f.prefix+"-delete-type"); em.persist(deviceType);
        var model = new DeviceModel(); model.setName(f.prefix+"-delete-model"); model.setDeviceType(f.deviceType); em.persist(model);
        var issue = new ServiceIssue(); issue.setName(f.prefix+"-delete-issue"); em.persist(issue);
        var catalog = new ServiceCatalogItem(); catalog.setName(f.prefix+"-delete-catalog"); catalog.setDeviceModel(f.model);
        catalog.setServiceType(f.serviceType); catalog.setServiceIssue(f.issue); catalog.setConfiguredPrice(BigDecimal.ONE);
        catalog.setStandardDurationMinutes(10); catalog.setWarrantyDays(0); em.persist(catalog);
        var part = new Part(); part.setPartCode(f.prefix+"-delete-part"); part.setName("Delete part");
        part.setSalePrice(BigDecimal.ONE); em.persist(part);
        var slot = new AppointmentSlot(); slot.setBranch(f.branch); slot.setAppointmentDate(LocalDate.now(clock).plusDays(20));
        slot.setStartTime(LocalTime.of(13,0)); slot.setEndTime(LocalTime.of(14,0)); em.persist(slot);
        var schedule = new TechnicianSchedule(); schedule.setTechnician(f.technician); schedule.setBranch(f.branch);
        schedule.setWorkDate(LocalDate.now(clock).plusDays(20)); schedule.setStartTime(LocalTime.of(14,0));
        schedule.setEndTime(LocalTime.of(15,0)); em.persist(schedule);
        em.flush();

        deleteAndAssertGone("/api/v1/admin/branches/", Branch.class, branch.getId(), true);
        deleteAndAssertGone("/api/v1/admin/device-types/", DeviceType.class, deviceType.getId(), true);
        deleteAndAssertGone("/api/v1/admin/device-models/", DeviceModel.class, model.getId(), true);
        deleteAndAssertGone("/api/v1/admin/service-issues/", ServiceIssue.class, issue.getId(), true);
        deleteAndAssertGone("/api/v1/admin/service-catalog-items/", ServiceCatalogItem.class, catalog.getId(), true);
        deleteAndAssertGone("/api/v1/admin/parts/", Part.class, part.getId(), true);
        deleteAndAssertGone("/api/v1/admin/appointment-slots/", AppointmentSlot.class, slot.getId(), true);
        deleteAndAssertGone("/api/v1/admin/technician-schedules/", TechnicianSchedule.class, schedule.getId(), false);
    }

    @Test void referencedAdminDataIsBlockedAndBusinessHistoryRemains() throws Exception {
        var part = new Part(); part.setPartCode(f.prefix+"-used-part"); part.setName("Used part");
        part.setSalePrice(BigDecimal.TEN); em.persist(part); f.catalog.setPart(part);
        var appointment = new Appointment();
        var customer = new Customer(); customer.setFullName("Reference customer"); customer.setPhone(f.prefix+"phone"); em.persist(customer);
        appointment.setCustomer(customer); appointment.setAppointmentSlot(f.slot); appointment.setBookedAt(java.time.LocalDateTime.now(clock));
        em.persist(appointment);
        var ticket = f.ticket(ServiceTicketStatus.REPAIRING);
        var repairItem = f.item(ticket);
        em.flush();

        var referenced = List.of(
                "/api/v1/admin/branches/"+f.branch.getId(),
                "/api/v1/admin/device-types/"+f.deviceType.getId(),
                "/api/v1/admin/device-models/"+f.model.getId(),
                "/api/v1/admin/service-issues/"+f.issue.getId(),
                "/api/v1/admin/service-types/"+f.serviceType.getId(),
                "/api/v1/admin/service-catalog-items/"+f.catalog.getId(),
                "/api/v1/admin/parts/"+part.getId(),
                "/api/v1/admin/appointment-slots/"+f.slot.getId());
        for (String url : referenced) {
            mvc.perform(delete(url).header("Authorization","Bearer "+token))
                    .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("CONFLICT"))
                    .andExpect(jsonPath("$.message").value(containsString("đang được sử dụng")));
        }

        assertNotNull(em.find(Appointment.class, appointment.getId()));
        assertNotNull(em.find(ServiceTicket.class, ticket.getId()));
        assertNotNull(em.find(RepairItem.class, repairItem.getId()));
        assertNotNull(em.find(Part.class, part.getId()));
        assertNotNull(em.find(ServiceCatalogItem.class, f.catalog.getId()));
    }

    @Test void nonAdminCannotCallAnyPhysicalDeleteEndpoint() throws Exception {
        String receptionistToken = login(f.receptionist);
        var urls = List.of(
                "/api/v1/admin/branches/"+f.branch.getId(),
                "/api/v1/admin/device-types/"+f.deviceType.getId(),
                "/api/v1/admin/device-models/"+f.model.getId(),
                "/api/v1/admin/service-issues/"+f.issue.getId(),
                "/api/v1/admin/service-types/"+f.serviceType.getId(),
                "/api/v1/admin/service-catalog-items/"+f.catalog.getId(),
                "/api/v1/admin/parts/"+f.catalog.getId(),
                "/api/v1/admin/appointment-slots/"+f.slot.getId(),
                "/api/v1/admin/technician-schedules/"+f.slot.getId());
        for (String url : urls) {
            mvc.perform(delete(url).header("Authorization","Bearer "+receptionistToken)).andExpect(status().isForbidden());
        }
    }

    @Test void deletingMissingAdminDataReturns404() throws Exception {
        for (String resource : List.of("branches", "device-types", "device-models", "service-issues", "service-types",
                "service-catalog-items", "parts", "appointment-slots", "technician-schedules")) {
            mvc.perform(delete("/api/v1/admin/"+resource+"/"+Long.MAX_VALUE).header("Authorization","Bearer "+token))
                    .andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("RESOURCE_NOT_FOUND"));
        }
    }

    private String login(User user) throws Exception {
        String response = mvc.perform(post("/api/v1/auth/login").contentType("application/json")
                        .content(json.writeValueAsString(new LoginRequest(user.getUsername(), ApiFixture.PASSWORD))))
                .andExpect(status().isOk()).andReturn().getResponse().getContentAsString();
        return json.readTree(response).get("accessToken").asString();
    }

    private <T> void deleteAndAssertGone(String baseUrl, Class<T> type, Long id, boolean hasGetEndpoint) throws Exception {
        mvc.perform(delete(baseUrl+id).header("Authorization","Bearer "+token)).andExpect(status().isNoContent());
        em.flush();
        em.clear();
        assertNull(em.find(type, id));
        if (hasGetEndpoint) {
            mvc.perform(get(baseUrl+id).header("Authorization","Bearer "+token))
                    .andExpect(status().isNotFound()).andExpect(jsonPath("$.code").value("RESOURCE_NOT_FOUND"));
        }
    }

}
